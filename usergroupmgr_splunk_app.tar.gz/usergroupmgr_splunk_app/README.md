# Splunk User Group Check-in Manager
## A Splunk App to manage user group data for Splunk User Groups

http://ug.splunkstart.com:8000

Currently in beta.